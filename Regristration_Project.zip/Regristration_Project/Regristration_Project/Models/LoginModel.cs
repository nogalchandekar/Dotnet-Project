﻿namespace Regristration_Project.Models
{
    public class LoginModel
    {

        public string EmailID { get; set; }
        public string Password { get; set; }
    }
}
